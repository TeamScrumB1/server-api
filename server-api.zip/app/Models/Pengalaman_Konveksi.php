<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pengalaman_Konveksi extends Model
{
    protected $guarded = [];
    protected $table ='pengalaman_konveksi';
    use HasFactory;
}
